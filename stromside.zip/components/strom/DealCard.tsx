// components/strom/DealCard.tsx
"use client";
import { formatNok } from "@/lib/strom/utils";

type Provider = { name: string; url: string | null };

type Props = {
  provider: Provider;
  monthlyEstimate: number;
  areaLabel: string;
  spotPriceNok?: number;
  monthlyFeeNok?: number;
  contractType?: string;
  variant?: "card" | "row"; // ← NYTT (default = "card")
};

export default function DealCard({
  provider,
  monthlyEstimate,
  areaLabel,
  spotPriceNok,
  monthlyFeeNok,
  contractType,
  variant = "card",
}: Props) {
  const typeLabel =
    contractType === "spot" ? "Spotpris" :
    contractType === "variable" ? "Variabel" :
    contractType === "fixed" ? "Fastpris" :
    contractType ?? "other";


if (variant === "row") {
  return (
    <div className="deal-box deal-scroll">
      <div className="deal-grid">
        {/* Venstre: navn (spenner 2 rader) */}
        <div className="deal-name">
          <div className="font-semibold truncate" style={{ color: "var(--text)" }}>
            {provider.name}
          </div>
        </div>

        {/* Topp-labels */}
        <div className="deal-h cell-center">Spotpris</div>
        <div className="deal-h cell-center">Månedsavgift</div>
        <div className="deal-h cell-right">Estimert pr. mnd</div>

        {/* Verdier */}
        <div className="cell-center num">
          {typeof spotPriceNok === "number" ? `${formatNok(spotPriceNok)}/kWh` : "—"}
        </div>
        <div className="cell-center num">
          {typeof monthlyFeeNok === "number" ? `${formatNok(monthlyFeeNok)}/mnd` : "—"}
        </div>
        <div className="cell-right num font-semibold">
          {formatNok(monthlyEstimate)}
        </div>

        {/* Høyre: CTA */}
        <div className="deal-cta">
          {provider.url && (
            <a
              href={provider.url}
              rel="nofollow sponsored"
              className="inline-flex items-center gap-1 px-4 py-2 rounded-full border transition"
              style={{ borderColor: "var(--border)", color: "var(--text)", background: "var(--surface-2)" }}
            >
              Les mer →
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
}