// lib/strom/utils.ts

/** ---------- Typer fra leverandørens API ---------- */
export type ApiOffer = {
  id: number;
  name: string;
  type: "hourly_spot" | "variable" | "fixed" | string;
  lastProductVersionId?: number;
  applicableToCustomerType?: string;
  orderUrl?: string;
  organization?: {
    id?: number;
    name?: string;
    slug?: string;
    pricelistUrl?: string;
    number?: number;
  };
  publishedAt?: string;
  updatedAt?: string;
  monthlyConsumption?: number | null; // kWh/mnd fra API (kan være null)
  fee?: {
    monthlyFee?: number | null;        // NOK
    finalMonthlyFee?: number | null;   // NOK
  };
  currentPrice?: {
    // Vanligvis i ØRE/kWh:
    addonPrice?: number | null;
    kwPrice?: number | null;
    spotPrice?: number | null;
    electricityPerKwh?: number | null;
    fullElectricityPerKwh?: number | null; // full (inkl. avgifter)
    finalPriceMonthly?: number | null; // NOK/mnd (API egen beregning)
    electricityMonthlyConsumptionPrice?: number | null; // NOK/mnd (energidelen)
    tax?: {
      vatExemption?: boolean;
      elCertificateExemption?: boolean;
      vatRatio?: number;
      consumerElectricityTax?: number;
      elCertificatePrice?: number;
    };
  };
  // Kan inneholde flere felter i virkeligheten – uproblematisk pga optional
};

/** ---------- Vår normaliserte domene-modell ---------- */
export type PriceDump = {
  id: string;
  name: string;
  provider?: string;
  contract_type?: string;         // "spot" | "variable" | "fixed" | ...
  region?: string | null;
  price_per_kwh_nok?: number;     // NOK/kWh (inkl. avgifter når mulig)
  monthly_fee_nok?: number;       // NOK/mnd
  product_url?: string;           // landingsside hos leverandør
};

/** ---------- Små hjelpefunksjoner ---------- */

const isFiniteNumber = (v: unknown): v is number =>
  typeof v === "number" && Number.isFinite(v);

const asNumber = (v: unknown | null | undefined, fallback = 0): number =>
  isFiniteNumber(v) ? (v as number) : fallback;

export function nok(n: number): string {
  return new Intl.NumberFormat("nb-NO", {
    style: "currency",
    currency: "NOK",
    maximumFractionDigits: 2,
  }).format(n);
}
export const formatNok = nok;

export const avg = (arr: number[]) =>
  arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;

/** Konverterer øre/kWh → NOK/kWh */
export function orePerKwhToNok(ore?: number | null): number {
  return isFiniteNumber(ore) ? ore / 100 : 0;
}

/**
 * Prøver å finne en best mulig NOK/kWh fra ApiOffer:
 * 1) fullElectricityPerKwh (foretrukket, inkl. avgifter)
 * 2) electricityPerKwh
 * 3) Hvis begge mangler, men vi har electricityMonthlyConsumptionPrice og monthlyConsumption,
 *    estimerer vi NOK/kWh = monthlyEnergy / monthlyConsumption.
 */
export function deriveNokPerKwhFromApi(api: ApiOffer): number | undefined {
  const full = orePerKwhToNok(api.currentPrice?.fullElectricityPerKwh);
  if (full > 0) return full;

  const base = orePerKwhToNok(api.currentPrice?.electricityPerKwh);
  if (base > 0) return base;

  const monthlyEnergy = asNumber(api.currentPrice?.electricityMonthlyConsumptionPrice, 0);
  const monthlyKwh = asNumber(api.monthlyConsumption, 0);

  if (monthlyEnergy > 0 && monthlyKwh > 0) {
    return monthlyEnergy / monthlyKwh;
  }
  return undefined;
}

/** Returnerer beste kjente månedlig fastbeløp (NOK/mnd) */
export function deriveMonthlyFeeFromApi(api: ApiOffer): number {
  const fee =
    isFiniteNumber(api.fee?.finalMonthlyFee) ? api.fee?.finalMonthlyFee :
    isFiniteNumber(api.fee?.monthlyFee) ? api.fee?.monthlyFee :
    0;
  return asNumber(fee, 0);
}

/** ---------- Kostnadsberegninger ---------- */

/**
 * Beregn månedspris fra vår normaliserte modell.
 * Brukes i UI (StromClient) hvor vi allerede har konvertert til NOK/kWh og NOK/mnd.
 */
export function monthlyCost(offer: PriceDump, kwhPerMonth: number): number {
  const perKwh = asNumber(offer.price_per_kwh_nok, 0);
  const fee = asNumber(offer.monthly_fee_nok, 0);
  return perKwh * kwhPerMonth + fee;
}

/**
 * Alternativ: beregn direkte fra ApiOffer (dersom du vil hoppe over mapping).
 * - Bruker oppgitt NOK/kWh hvis kjent.
 * - Ellers skalerer vi fra API sin `finalPriceMonthly` eller `electricityMonthlyConsumptionPrice`,
 *   dersom `monthlyConsumption` finnes, til etterspurt kWh/mnd.
 */
export function monthlyCostFromApi(api: ApiOffer, kwhPerMonth: number): number {
  const perKwh = deriveNokPerKwhFromApi(api);
  const fee = deriveMonthlyFeeFromApi(api);

  if (isFiniteNumber(perKwh)) {
    return perKwh! * kwhPerMonth + fee;
  }

  // Skaler fra API-beregninger dersom tilgjengelig:
  const apiMonthly = asNumber(
    api.currentPrice?.finalPriceMonthly ??
      api.currentPrice?.electricityMonthlyConsumptionPrice,
    0
  );
  const apiKwh = asNumber(api.monthlyConsumption, 0);

  if (apiMonthly > 0 && apiKwh > 0) {
    const perKwhEstimated = apiMonthly / apiKwh;
    return perKwhEstimated * kwhPerMonth + fee;
  }

  return fee; // fall-back
}

/** ---------- Mapping fra API → vår modell ---------- */

export function mapApiOfferToPriceDump(api: ApiOffer): PriceDump {
  const priceNok = deriveNokPerKwhFromApi(api);
  const monthlyFee = deriveMonthlyFeeFromApi(api);

  // Normaliser kontraktstype
  const type = api.type === "hourly_spot" ? "spot" : api.type;

  return {
    id: String(api.id),
    name: api.name,
    provider: api.organization?.name,
    contract_type: type,
    region: null, // legg inn hvis API har region
    price_per_kwh_nok: priceNok,
    monthly_fee_nok: monthlyFee,
    product_url: api.orderUrl,
  };
}
/** Punkter til sparkline-grafen (timestamp + pris) */
export type PricePoint = { x: number | Date; y: number };
