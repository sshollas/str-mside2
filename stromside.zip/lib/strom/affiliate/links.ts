// lib/affiliate/links.ts
type AffiliateLinkInput = {
  programId: string;     // bruk f.eks. offer.id
  targetUrl?: string;    // orderUrl fra API
  subId?: string;        // egen click-id
  campaign?: string;
  medium?: string;
  source?: string;
};

export function buildAffiliateUrl({
  programId, targetUrl, subId,
  campaign = "strom-sammenligning",
  medium = "affiliate",
  source = "stromsite",
}: AffiliateLinkInput): string {
  const base = process.env.NEXT_PUBLIC_AFF_TRACK_BASE!;
  const affId = process.env.NEXT_PUBLIC_AFFILIATE_ID!;
  const spaceId = process.env.NEXT_PUBLIC_AFF_SPACE_ID!;

  const params = new URLSearchParams();
  params.set("a", affId);
  params.set("as", spaceId);
  params.set("pid", programId); // eller riktig param ifølge nettverket
  if (subId) params.set("subid", subId);

  if (targetUrl?.startsWith("http")) {
    const u = new URL(targetUrl);
    u.searchParams.set("utm_source", source);
    u.searchParams.set("utm_medium", medium);
    u.searchParams.set("utm_campaign", campaign);
    params.set("url", u.toString());
  }

  return `${base}?${params.toString()}`;
}
