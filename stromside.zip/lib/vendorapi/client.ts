// lib/vendorapi/client.ts
import { ApiOffer } from "@/lib/strom/utils";

export async function fetchOffersFromApi(): Promise<ApiOffer[]> {
  const base = process.env.VENDOR_API_BASE;
  const key = process.env.VENDOR_API_KEY;

  if (!base || !key) throw new Error("VENDOR_API_* mangler i .env");

  const res = await fetch(`${base}/offers`, {
    headers: { Authorization: `Bearer ${key}` },
    next: { revalidate: 900 }, // 15 min ISR
  });

  if (!res.ok) throw new Error(`API ${res.status}: ${await res.text()}`);
  const data = await res.json();
  return Array.isArray(data) ? data : data.offers ?? [];
}
