"use client";

import { useMemo, useState } from "react";
import { monthlyCost, type PriceDump } from "@/lib/strom/utils";
import { buildAffiliateUrl } from "@/lib/strom/affiliate/links";
import DealCard from "@/components/strom/DealCard";
import FloatingFilter, { type ContractType } from "@/components/strom/FloatingFilter";

type Props = { initialOffers: PriceDump[] };

const AREAS = [
  { code: "NO1", name: "Øst-Norge" },
  { code: "NO2", name: "Sør-Norge" },
  { code: "NO3", name: "Midt-Norge" },
  { code: "NO4", name: "Nord-Norge" },
  { code: "NO5", name: "Vest-Norge" },
] as const;

export default function StromClient({ initialOffers }: Props) {
  const [usage, setUsage] = useState<number>(1000);
  const [areaCode, setAreaCode] = useState<string>(AREAS[0].code);
  const [contract, setContract] = useState<ContractType>(null);
  const [sort, setSort] = useState<"price" | "name">("price");
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);

  const filtered = useMemo(() => {
    let out = initialOffers;
    if (query) {
      const q = query.toLowerCase();
      out = out.filter(
        (o) =>
          o.name.toLowerCase().includes(q) ||
          (o.provider ?? "").toLowerCase().includes(q)
      );
    }
    if (contract) out = out.filter((o) => o.contract_type === contract);
    return out;
  }, [initialOffers, query, contract]);

  const kwh = usage;

  const sorted = useMemo(() => {
    const items = [...filtered];
    if (sort === "name") items.sort((a, b) => a.name.localeCompare(b.name));
    else items.sort((a, b) => monthlyCost(a, kwh) - monthlyCost(b, kwh));
    return items;
  }, [filtered, sort, kwh]);

  const clickId =
    typeof window !== "undefined" ? window.crypto?.randomUUID?.() ?? "" : "";

  const applyLabel = `Vis ${sorted.length} avtale${sorted.length === 1 ? "" : "r"}`;

  const resetAll = () => {
    setQuery("");
    setContract(null);
    setSort("price");
    setUsage(1000);
    setAreaCode(AREAS[0].code);
  };

  return (
    <div className="relative">
      {/* FAB-knapp */}
      <button
        onClick={() => setOpen(true)}
        className="fab"
        aria-label="Åpne filtre"
        title="Filtre"
      >
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden>
          <path d="M3 5h18M6 12h12M10 19h4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </button>

      {/* Flytende filterpanel */}
      <FloatingFilter
        open={open}
        onClose={() => setOpen(false)}
        areas={AREAS as any}
        areaCode={areaCode}
        onChangeArea={setAreaCode}
        usage={usage}
        onChangeUsage={setUsage}
        contract={contract}
        onChangeContract={setContract}
        sort={sort}
        onChangeSort={setSort}
        query={query}
        onChangeQuery={setQuery}
        onReset={resetAll}
        applyLabel={applyLabel}
      />

      {/* Tabell-liste */}
      <div className="deal-list">
        <div className="deal-inner">


          {sorted.map((o) => {
            const monthlyEstimate = monthlyCost(o, kwh);
            const affiliateUrl = buildAffiliateUrl({
              programId: o.id,
              targetUrl: o.product_url,
              subId: clickId,
            });

            return (
              <DealCard
                key={o.id}
                variant="row"
                provider={{ name: o.provider ?? o.name, url: affiliateUrl ?? null }}
                monthlyEstimate={monthlyEstimate}
                areaLabel={AREAS.find((a) => a.code === areaCode)?.name ?? areaCode}
                spotPriceNok={o.price_per_kwh_nok}
                monthlyFeeNok={o.monthly_fee_nok}
                contractType={o.contract_type ?? undefined}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
}
