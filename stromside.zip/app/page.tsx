// app/page.tsx
import StromClient from "./strom/StromClient";
import { mapApiOfferToPriceDump, type ApiOffer, type PriceDump } from "@/lib/strom/utils";
// Bruk stien der klienten DIN faktisk ligger:
import { fetchOffersFromApi } from "@/lib/vendorapi/client"; // <- evt. "@/lib/vendorapi/client"
import path from "node:path";
import { readFile } from "node:fs/promises";

// I utvikling: ingen caching. I prod kan du sette 900 (15 min) el.l.
export const revalidate = 0;

async function loadMockOffers(): Promise<ApiOffer[]> {
  const file = path.join(process.cwd(), "data", "stromapi-mockup.json");
  const raw = await readFile(file, "utf-8");
  const json = JSON.parse(raw);
  // Aksepter både [ ... ] og { offers: [ ... ] }
  return Array.isArray(json) ? (json as ApiOffer[]) : (json.offers ?? []);
}

export default async function Home() {
  let offers: PriceDump[] = [];

  try {
    const raw = await fetchOffersFromApi();
    offers = raw.map(mapApiOfferToPriceDump);
  } catch {
    const raw = await loadMockOffers();
    offers = raw.map(mapApiOfferToPriceDump);
  }

  return <StromClient initialOffers={offers} />;
}
